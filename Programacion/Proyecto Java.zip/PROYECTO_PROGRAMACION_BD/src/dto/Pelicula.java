package dto;
import java.util.List;

import conexion.conexionBaseDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Pelicula {
    private int id;
    private String titulo;
    private int año;
    private int duracion;
    private String resumen;
    private Genero genero;
	private List<Actor> actores;


    /**
     * Constructor para crear una nueva película.
     * @param idPelicula 
     * @param titulo     
     * @param año      
     * @param duracion  
     * @param resumen   
     * @param genero
     */
    // Constructor
    public Pelicula(int id, String titulo, int año, int duracion, String resumen, Genero genero) {
        this.id = id;
        this.titulo = titulo;
        this.año = año;
        this.duracion = duracion;
        this.resumen = resumen;
        this.genero = genero;
    }


    // GET Y SET
    public int getIdPelicula() {
		return id;
	}

	public void setIdPelicula(int idPelicula) {
		this.id = idPelicula;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getAño() {
		return año;
	}

	public void setAño(int año) {
		this.año = año;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	public String getResumen() {
		return resumen;
	}

	public void setResumen(String resumen) {
		this.resumen = resumen;
	}

	public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	public List<Actor> getActores() {
	    return this.actores;
	}
	
	public void setActores(List<Actor> actores) {
		this.actores = actores;
	}

    // Métodos para gestión de actores en pelicula
	/** Agregar actor a una pelicula
	 * @param Actor
	 */
	 public void agregarActor(Actor actor) {
        if (!actores.contains(actor)) {
            actores.add(actor);
        }
    }

    /**
     * Elimina un actor de la película. 
     * @return true si se eliminó correctamente, false si el actor no estaba en la película
     */
	 public boolean eliminarActor(Actor actor) {
		    return actores.remove(actor);
		}
	 
	 @Override
    public String toString() {
        return titulo + " (" + año + ") - " + genero + " - " + duracion + " mins";   
 }

   // Guarda la película en la base de datos.
        public void guardar() {
            try (Connection conn = conexionBaseDatos.getConnection()) {
                String sql = "INSERT INTO peliculas (id, titulo, año, duracion, resumen, genero) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, this.id);
                stmt.setString(2, this.titulo);
                stmt.setInt(3, this.año);
                stmt.setInt(4, this.duracion);
                stmt.setString(5, this.resumen);
                stmt.setString(6, this.genero.toString());
                stmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
         }
    }
}