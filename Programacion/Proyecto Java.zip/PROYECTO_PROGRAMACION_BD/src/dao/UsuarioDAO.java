package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import dto.Pelicula;
import dto.Genero;
import dto.Actor;

/**
 * Clase DAO para las operaciones de usuario en el sistema
 * Con métodos de consulta para películas, actores y géneros
 */
public class UsuarioDAO {
    private List<Pelicula> peliculas;
    private List<Actor> actores;

    /**
     * Constructor que inicializa las listas de datos.
     * @param peliculas 
     * @param actores
     */
    public UsuarioDAO(List<Pelicula> peliculas, List<Actor> actores) {
        this.peliculas = new ArrayList<>(peliculas);
        this.actores = new ArrayList<>(actores);
    }

    // MÉTODOS PARA CONSULTA DE PELÍCULAS
    /**
     * Busca una película por su título
     * @param titulo Título o parte del título a buscar
     * @return Lista de películas que coinciden
     */
    public List<Pelicula> buscarPeliculaPorTitulo(String titulo) {
        List<Pelicula> resultado = new ArrayList<>();
        for (Pelicula p : peliculas) {
            if (p.getTitulo().toLowerCase().contains(titulo.toLowerCase())) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    /**
     * Filtra películas por género.
     * @param genero Género para filtrar
     * @return Lista de películas del género especificado (lista vacía si no hay coincidencias)
     */
    public List<Pelicula> filtrarPeliculasPorGenero(Genero genero) {
        List<Pelicula> resultado = new ArrayList<>();
        for (Pelicula p : peliculas) {
            if (p.getGenero() == genero) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    /**
     * Obtiene películas estrenadas en un año específico.
     * @param año Año de estreno a buscar
     * @return Lista de películas estrenadas ese año (lista vacía si no hay coincidencias)
     */
    public List<Pelicula> buscarPeliculasPorAño(int año) {
        List<Pelicula> resultado = new ArrayList<>();
        for (Pelicula p : peliculas) {
            if (p.getAño() == año) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    /**
     * Obtiene todas las películas disponibles ordenadas por título.
     * @return Lista completa de películas ordenadas alfabéticamente
     */
    public List<Pelicula> listarTodasLasPeliculas() {
        List<Pelicula> copia = new ArrayList<>(peliculas);
        copia.sort((p1, p2) -> p1.getTitulo().compareToIgnoreCase(p2.getTitulo()));
        return copia;
    }

    // MÉTODOS PARA CONSULTA DE ACTORES
    /**
     * Busca un actor por nombre o apellido (búsqueda insensible a mayúsculas).
     * @param nombre Nombre o parte del nombre a buscar
     * @return Lista de actores que coinciden con el criterio (lista vacía si no hay coincidencias)
     */
    public List<Actor> buscarActorPorNombre(String nombre) {
        List<Actor> resultado = new ArrayList<>();
        for (Actor a : actores) {
            if (a.getNombre().toLowerCase().contains(nombre.toLowerCase()) ||
                a.getApellido().toLowerCase().contains(nombre.toLowerCase())) {
                resultado.add(a);
            }
        }
        return resultado;
    }

    /**
     * Filtra actores por nacionalidad.
     * @param nacionalidad Nacionalidad a buscar
     * @return Lista de actores de la nacionalidad especificada (lista vacía si no hay coincidencias)
     */
    public List<Actor> filtrarActoresPorNacionalidad(String nacionalidad) {
        List<Actor> resultado = new ArrayList<>();
        for (Actor a : actores) {
            if (a.getNacionalidad().equalsIgnoreCase(nacionalidad)) {
                resultado.add(a);
            }
        }
        return resultado;
    }

    /**
     * Obtiene la filmografía completa de un actor.
     * @param idActor
     * @return Lista de películas en las que ha participado el actor
     */
    public List<Pelicula> obtenerFilmografiaActor(int idActor) {
        List<Pelicula> resultado = new ArrayList<>();
        
        // Verificar si el actor existe
        boolean actorExiste = actores.stream()
                       .anyMatch(a -> a.getId() == idActor);
        
        if (actorExiste) {
            // Filtrar las películas donde aparece este actor
            resultado = peliculas.stream()
                               .filter(p -> p.getActores().stream()
                                           .anyMatch(a -> a.getId() == idActor))
                               .collect(Collectors.toList());
        }
        return resultado;
    }
    
    /**
     * Obtiene todos los actores registrados ordenados alfabéticamente.
     * @return Lista completa de actores ordenada por apellido
     */
    public List<Actor> listarTodosLosActores() {
        List<Actor> copia = new ArrayList<>(actores);
        copia.sort((a1, a2) -> a1.getApellido().compareToIgnoreCase(a2.getApellido()));
        return copia;
    }

    // MÉTODOS PARA GÉNEROS
    /**
     * Obtiene todos los géneros cinematográficos disponibles.
     * @return Lista de todos los géneros
     */
    public List<Genero> listarTodosLosGeneros() {
        return List.of(Genero.values());
    }

    /**
     * Obtiene las estadísticas de películas por género.
     * @return ceutna las películas por cada género
     */
    public Map<Genero, Long> obtenerEstadisticasPorGenero() {
        return peliculas.stream()
               .collect(Collectors.groupingBy(
               Pelicula::getGenero,
               Collectors.counting()
       ));
    }
}